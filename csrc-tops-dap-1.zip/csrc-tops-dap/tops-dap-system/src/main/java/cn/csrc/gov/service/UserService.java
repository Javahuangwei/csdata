package cn.csrc.gov.service;

import cn.csrc.gov.core.domain.R;

public interface UserService {

    R<Object> selectAllUser();
}

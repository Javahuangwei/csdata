package cn.csrc.gov.pojo;


import lombok.Data;

/**
 * HJL
 * 2023/3/8
 */
@Data
public class User {
    public String name;
    public int age;
}

package cn.csrc.gov.service;

public interface UserService {
    String selectAllUser();
}

package cn.csrc.gov.controller;

import cn.csrc.gov.core.domain.R;
import cn.csrc.gov.service.UserService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * HJL
 * 2023/3/8
 */
@Slf4j
@RestController
public class UserController {

    @Autowired
    private UserService userService;

    @GetMapping("/selectAllUser")
    public R<Object> selectAllUser() {
        return userService.selectAllUser();
    }
}

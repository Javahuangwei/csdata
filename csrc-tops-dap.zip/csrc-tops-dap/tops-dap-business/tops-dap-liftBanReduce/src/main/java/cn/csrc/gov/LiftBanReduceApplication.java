package cn.csrc.gov;

import cn.csrc.gov.swagger.annotation.EnableCustomSwagger2;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * HJL
 * 2023/3/8
 * 解禁减持业务
 */
@EnableCustomSwagger2
@SpringBootApplication
public class LiftBanReduceApplication {
    public static void main(String[] args) {
        SpringApplication.run(LiftBanReduceApplication.class, args);
    }
}
